# -*- coding: utf-8 -*-
"""
Created on Wed Nov 22 16:24:42 2023

@author: charl
"""

import numpy as np
import pandas as pd
import joblib
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score
import os
import matplotlib.pyplot as plt
import seaborn as sns
from sklearn.model_selection import RandomizedSearchCV
from sklearn.model_selection import learning_curve
from sklearn.metrics import confusion_matrix


####################### Flowers Dataset #######################

def flowers():
    flower_data = pd.read_csv("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/IRIS_ Flower_Dataset.csv")

    print(flower_data.head())

    x = flower_data.drop('species', axis=1)
    y = flower_data['species']
    
    # Split
    x_train, x_test, y_train, y_test = train_test_split(x, y, test_size=0.2, random_state=42)

    flower_model = RandomForestClassifier(n_estimators=200, random_state=42)

    flower_model.fit(x_train, y_train)

    y_pred = flower_model.predict(x_test)

    accuracy = accuracy_score(y_test, y_pred)
    print(f"The accuracy is : {accuracy}")
    
    # Model Saving
    model_filename = os.path.join("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI", 'Final Model - Flowers Dataset')
    joblib.dump(flower_model, model_filename)

    #Graphs 
    
        # Learning Curve
    train_sizes, train_scores, test_scores = learning_curve(flower_model, x, y, cv=5, scoring='accuracy', n_jobs=-1)

    plt.figure(figsize=(10, 6))
    plt.plot(train_sizes, np.mean(train_scores, axis=1), label='Training Accuracy')
    plt.plot(train_sizes, np.mean(test_scores, axis=1), label='Validation Accuracy')
    plt.title('Learning Curve')
    plt.xlabel('Training Examples')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.savefig("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/Graph 1 Flowers.png")
    plt.show()

        # Feature Importance
    feature_importance = flower_model.feature_importances_
    features = x.columns

    plt.figure(figsize=(10, 6))
    sns.barplot(x=feature_importance, y=features)
    plt.title('Feature Importance')
    plt.xlabel('Importance')
    plt.ylabel('Features')
    plt.savefig("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/Graph 2 Flowers.png")
    plt.show()

        # Confusion Matrix
    y_pred = flower_model.predict(x_test)
    cm = confusion_matrix(y_test, y_pred)
    
    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=flower_model.classes_, yticklabels=flower_model.classes_)
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.savefig("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/Graph 3 Flowers.png")
    plt.show()

    print("Titanic Function Over / Exit")

    

####################### Titanic Dataset #######################

def titanic():
    titanic_data_gendersub = pd.read_csv("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/titanic/gender_submission.csv")
    titanic_data_test = pd.read_csv("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/titanic/test.csv")
    titanic_data_train = pd.read_csv("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/titanic/train.csv")

    # Test cleaning 
    titanic_data_test = titanic_data_test.drop(columns=['Ticket', 'Cabin', 'Name'])   # Drop useless columns
    titanic_data_test['Sex'] = titanic_data_test['Sex'].map({'male': 0, 'female': 1})   # Change male/female to 0 and 1 in the 'Sex' column
    titanic_data_test['Age'].fillna(titanic_data_test['Age'].median(), inplace=True)     # Fill the missing values in 'Age' with the median values of the 'Age' column
    titanic_data_test['Embarked'] = titanic_data_test['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})  # Change the S/C/Q in the 'Embarked' column to 0/1/2
    titanic_data_test['Fare'].fillna(titanic_data_test['Fare'].median(), inplace=True)    # Fill the missing values in 'Fare' with the median values of the 'Fare' column


    # Train cleaning
    titanic_data_train = titanic_data_train.drop(columns=['Ticket', 'Cabin', 'Name'])   # Drop useless columns
    titanic_data_train['Sex'] = titanic_data_train['Sex'].map({'male': 0, 'female': 1})   # Change male/female to 0 and 1 in the 'Sex' column
    titanic_data_train['Age'].fillna(titanic_data_train['Age'].median(), inplace=True)     # Fill the missing values in 'Age' with the median values of the 'Age' column
    titanic_data_train['Embarked'] = titanic_data_train['Embarked'].map({'S': 0, 'C': 1, 'Q': 2})  # Change the S/C/Q in the 'Embarked' column to 0/1/2
    titanic_data_train['Embarked'].fillna(0.0, inplace=True)   #Fill the missing values in 'Embarked' column with 0.0

    # Feature engineering
    titanic_data_train['FamilySize'] = titanic_data_train['SibSp'] + titanic_data_train['Parch']
    titanic_data_test['FamilySize'] = titanic_data_test['SibSp'] + titanic_data_test['Parch']


    """
    nan_count_per_column = titanic_data_train.isnull().sum()
    print("\nNumber of NaN values in each column:")
    print(nan_count_per_column)
                                                                    #this part is useful to check in which columns there is empty cells
    nan_count_per_column2 = titanic_data_test.isnull().sum()
    print("\nNumber of NaN values in each column:")
    print(nan_count_per_column2)
    """


    # Split
    train_train = titanic_data_train.drop('Survived', axis=1)
    train_val = titanic_data_train['Survived']


    test_train = titanic_data_test

    # Hyperparameters
    param_dist = {
        'n_estimators': [100, 500, 1000],
        'max_depth': [None, 10, 20],
        'min_samples_split': [2, 5, 10],
        'min_samples_leaf': [1, 2, 4],
        'max_features': ['auto', 'sqrt', 'log2', None]
    }

    
    titanic_model = RandomForestClassifier(random_state=42)
    random_search = RandomizedSearchCV(titanic_model, param_distributions=param_dist, n_iter=10, cv=5, scoring='accuracy', n_jobs=-1)
    random_search.fit(train_train, train_val)

    
    print("Best Hyperparameters:", random_search.best_params_)

    best_model = random_search.best_estimator_
    y_pred = best_model.predict(test_train)

    accuracy = accuracy_score(titanic_data_gendersub['Survived'], y_pred)
    print(f"The accuracy is: {accuracy}")
    
    #Model Saving
    model_filename = os.path.join("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI", 'Final Best Model - Titanic Dataset')
    joblib.dump(best_model, model_filename)

    #Graphs 
    
        #Learning Curve
    train_sizes, train_scores, test_scores = learning_curve(best_model, train_train, train_val, cv=5, scoring='accuracy', n_jobs=-1)

    plt.figure(figsize=(10, 6))
    plt.plot(train_sizes, np.mean(train_scores, axis=1), label='Training Accuracy')
    plt.plot(train_sizes, np.mean(test_scores, axis=1), label='Validation Accuracy')
    plt.title('Learning Curve')
    plt.xlabel('Training Examples')
    plt.ylabel('Accuracy')
    plt.legend()
    plt.show()
    plt.savefig("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/Graph 1 Titanic.png")
    
        # Feature importance
    feature_importance = best_model.feature_importances_
    features = train_train.columns
    
    plt.figure(figsize=(10, 6))
    sns.barplot(x=feature_importance, y=features)
    plt.title('Feature Importance')
    plt.xlabel('Importance')
    plt.ylabel('Features')
    plt.show()
    plt.savefig("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/Graph 2 Titanic.png")

        # Confusion matrix
    cm = confusion_matrix(titanic_data_gendersub['Survived'], y_pred)

    plt.figure(figsize=(8, 6))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", xticklabels=['0', '1'], yticklabels=['0', '1'])
    plt.title('Confusion Matrix')
    plt.xlabel('Predicted')
    plt.ylabel('True')
    plt.show()
    plt.savefig("C:/Users/charl/OneDrive/Bureau/Mini-Projects - Data Science & AI/Graph 3 Titanic.png")
    
    print("Titanic Function Over / Exit")






############################ Main ############################

def main():
    print("Welcome to the dataset selection program!")
    print("Choose a dataset:")
    print("1. Flowers")
    print("2. Titanic")

    choice = input("Enter the number of your choice: ")

    if choice == '1':
        flowers()
    elif choice == '2':
        titanic()
    else:
        print("Invalid choice. Please enter either '1' or '2'.")
        
main()

